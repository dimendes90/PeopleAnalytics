
#//pip install requests

import requests

url = "https://api.openai.com/v1/chat/completions"
headers = {
    "Authorization": "Bearer sk-c4bac565e0254672a2b6322a0d41053f",
    "Content-Type": "application/json",
}
data = {
    "model": "gpt-4-turbo",
    "messages": [{"role": "user", "content": "Olá, como você está?"}]
}

response = requests.post(url, headers=headers, json=data)

print(response.json())