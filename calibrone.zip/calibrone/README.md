# Calibrone Script Usage Guide

The `calibrone.py` script is designed to process calibration data, specifically for managing calibration folders and files within a shared drive environment.

- [Calibrone Script Usage Guide](#calibrone-script-usage-guide)
- [Prerequisites](#prerequisites)
  - [Installation](#installation)
  - [Usage](#usage)
- [Documentation](#documentation)
- [Support](#support)
- [Contributing](#contributing)

# Prerequisites

Before you can run the script, ensure you have the following prerequisites:

- Python 3.11 or higher installed on your machine.
- Access to a shared drive with the necessary calibration folders and files.
- The `calibration_file` CSV format should match the expected structure as defined by the script requirements.

## Installation

To use the `calibrone.py` script, follow these installation steps:

1. Clone the repository containing the script to your local machine (assuming the script is hosted in a repository). If not directly provided, you might need to create a new Python script file and copy the code into it.

    ```bash
    git clone https://github.com/neon/calibrone.git
    cd calibrone
    ```

2. Ensure you have Python installed. You can check your Python version by running:

    ```bash
    python --version
    ```

    If Python is not installed, download and install it from [python.org](https://www.python.org/).

3. (Optional) It's recommended to use a virtual environment for Python projects. Set up a virtual environment by running:

    ```bash
    python -m venv venv
    source venv/bin/activate  # On Windows use `venv\Scripts\activate`
    ```

4. Install any dependencies required by the script (if applicable).
   
    ```bash
    pip install - r requirements.txt
    ```

## Usage

To run the `calibrone.py` script, you need to provide three required arguments:

- `--root_shared_drive_id`: The root folder ID for the Calibration folder coming from Qulture Rocks.
- `--calibration_folder_id`: The Calibration folder ID, which needs to be the Macro folder ID.
- `--calibration_file`: The path to the CSV file containing the calibration rooms data.

Here is an example command to run the script:

```bash
python calibrone.py --root_shared_drive_id "YOUR_ROOT_SHARED_DRIVE_ID" --calibration_folder_id "YOUR_CALIBRATION_FOLDER_ID" --calibration_file "PATH_TO_YOUR_CALIBRATION_FILE"
```
Replace YOUR_ROOT_SHARED_DRIVE_ID, YOUR_CALIBRATION_FOLDER_ID, and PATH_TO_YOUR_CALIBRATION_FILE with the actual values relevant to your setup.

# Documentation

For more detailed information on how to organize and evaluate calibration files, please refer to the [documentation](docs/documentation.md).

# Support
For any issues or questions regarding the script, please refer to the repository's issues section or contact the maintainer directly.

# Contributing
Contributions to improve the script or documentation are welcome. Please follow the project's contributing guidelines when submitting pull requests.