#pip install requests

import requests

# Sua chave de API da OpenAI
api_key = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6Ijg5MzJkYzMyLTQ0MDYtNDQ4OS04MmQ2LTk2MGRiYmVmNDFlYSIsImV4cCI6MTczMjM3OTQ1M30.SDjMsUEqIvT_zV4ZItEcxRzy20corVVhiBz1lnilXnU'

# O endpoint da API
url = 'https://api.openai.com/v1/chat/completions'

# O cabeçalho da requisição
headers = {
    'Authorization': f'Bearer {api_key}',
    'Content-Type': 'application/json',
}

# O corpo da requisição
data = {
    'model': 'gpt-3.5-turbo',  # Ou o modelo que você preferir
    'messages': [
        {'role': 'user', 'content': 'Olá, como você está?'}
    ],
    'max_tokens': 100,  # Número máximo de tokens na resposta
}

# Fazendo a requisição POST
response = requests.post(url, headers=headers, json=data)

# Verificando se a requisição foi bem-sucedida
if response.status_code == 200:
    response_data = response.json()
    print(response_data['choices'][0]['message']['content'])
else:
    print(f'Erro: {response.status_code}, {response.text}')