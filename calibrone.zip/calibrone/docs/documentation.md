# Table of Contents

* [libs/organize\_evaluation\_files](#libs/organize_evaluation_files)
  * [Employee](#libs/organize_evaluation_files.Employee)
  * [csv\_to\_json\_transformed](#libs/organize_evaluation_files.csv_to_json_transformed)
  * [build\_org\_hierarchy](#libs/organize_evaluation_files.build_org_hierarchy)
  * [create\_service](#libs/organize_evaluation_files.create_service)
  * [list\_files\_in\_google\_drive](#libs/organize_evaluation_files.list_files_in_google_drive)
  * [copy\_file\_to\_folder](#libs/organize_evaluation_files.copy_file_to_folder)
  * [move\_files\_google\_drive](#libs/organize_evaluation_files.move_files_google_drive)
  * [set\_folder\_permissions](#libs/organize_evaluation_files.set_folder_permissions)
  * [create\_google\_drive\_folder](#libs/organize_evaluation_files.create_google_drive_folder)
  * [create\_shared\_drive](#libs/organize_evaluation_files.create_shared_drive)
  * [search\_employee](#libs/organize_evaluation_files.search_employee)
  * [find\_upper\_managers\_hierarchy](#libs/organize_evaluation_files.find_upper_managers_hierarchy)
  * [extract\_unique\_orgs\_and\_levels](#libs/organize_evaluation_files.extract_unique_orgs_and_levels)

<a id="libs/organize_evaluation_files"></a>

# libs/organize\_evaluation\_files

<a id="libs/organize_evaluation_files.Employee"></a>

## Employee Objects

```python
class Employee(BaseModel)
```

Represents an employee in the organization.

**Attributes**:

- `name` _str_ - The name of the employee.
- `email` _str_ - The email address of the employee.
- `manager` _str_ - The name of the employee's manager.
- `role` _str_ - The role of the employee.
- `level` _str_ - The level of the employee.
- `org_name` _str_ - The name of the organization the employee belongs to.

<a id="libs/organize_evaluation_files.csv_to_json_transformed"></a>

#### csv\_to\_json\_transformed

```python
def csv_to_json_transformed(filename)
```

Transforms a CSV file into a JSON string with specific transformations applied to the data, including
converting the 'email' field to lowercase, and capitalizing the 'name', 'manager', 'role', 'level', and 'org_name' fields.
Validates each row against a schema before transformation.

**Arguments**:

- `filename` _str_ - The path to the CSV file.
  

**Returns**:

- `str` - A JSON string representing the transformed data.
  

**Raises**:

- `FileNotFoundError` - If the specified file does not exist.
- `UnicodeDecodeError` - If there is an issue decoding the file.
- `ValidationError` - If a row does not conform to the expected schema.

<a id="libs/organize_evaluation_files.build_org_hierarchy"></a>

#### build\_org\_hierarchy

```python
def build_org_hierarchy(employees_json)
```

Builds an organizational hierarchy based on a list of employees.

**Arguments**:

- `employees_json` _str or list_ - A JSON string or a list of dictionaries representing employees.
  

**Returns**:

- `str` - A JSON string representing the organizational hierarchy.
  

**Raises**:

  None
  

**Example**:

  employees_json = '[{"name": "Pamella Feitosa De Oliveira", "email": "pamella.feitosa@neon.com.br", "manager": "Scheila Dantas Da Conceicao", "role": "ANL DE NEGOCIOS JR", "level": "OPER - L1", "org_name": "CoE Customer Experience"}]'
  org_hierarchy = build_org_hierarchy(employees_json)
  print(org_hierarchy)

<a id="libs/organize_evaluation_files.create_service"></a>

#### create\_service

```python
def create_service()
```

Creates a Google Drive service object using the user's credentials.

**Returns**:

- `service` _googleapiclient.discovery.Resource_ - Google Drive service object.
  

**Raises**:

- `FileNotFoundError` - If the token.pickle file is not found.
- `google.auth.exceptions.RefreshError` - If the credentials are not valid or expired.
- `google.auth.exceptions.DefaultCredentialsError` - If the credentials file is not found.

<a id="libs/organize_evaluation_files.list_files_in_google_drive"></a>

#### list\_files\_in\_google\_drive

```python
def list_files_in_google_drive(folder_id)
```

Lists all files in a specified Google Drive folder and returns their IDs and names.

**Arguments**:

- `folder_id` _str_ - The ID of the folder to list files from.
  

**Returns**:

  list of tuples: A list of tuples, each containing the file ID and name, found in the specified folder.

<a id="libs/organize_evaluation_files.copy_file_to_folder"></a>

#### copy\_file\_to\_folder

```python
def copy_file_to_folder(file_id, target_folder_id)
```

Copies a file from its current location to a specified folder in Google Drive.

**Arguments**:

- `service` - Authenticated Google Drive service instance.
- `file_id` _str_ - The ID of the file to copy.
- `target_folder_id` _str_ - The ID of the folder to copy the file to.
  

**Returns**:

  The copied file's ID if successful, None otherwise.

<a id="libs/organize_evaluation_files.move_files_google_drive"></a>

#### move\_files\_google\_drive

```python
def move_files_google_drive(destination_folder_id, file_id)
```

Moves a file in Google Drive from one folder to another.

**Arguments**:

- `destination_folder_id` _str_ - The ID of the destination folder.
- `file_id` _str_ - The ID of the file to be moved.
  

**Returns**:

  None

<a id="libs/organize_evaluation_files.set_folder_permissions"></a>

#### set\_folder\_permissions

```python
def set_folder_permissions(folder_id, user_email, role="writer")
```

Sets permission for a user on a Google Drive folder.

**Arguments**:

- `folder_id`: ID of the Google Drive folder.
- `user_email`: Email address of the user to grant permissions to.
- `role`: The role to grant ('reader', 'writer', etc.).

<a id="libs/organize_evaluation_files.create_google_drive_folder"></a>

#### create\_google\_drive\_folder

```python
def create_google_drive_folder(folder_name, permissions=None, parent_id=None)
```

Creates a Google Drive folder with an optional permissions parameter and an optional parent folder ID.
If a folder with the same name and parent already exists, returns its ID instead of creating a new one.

**Arguments**:

- `folder_name` _str_ - The name of the folder to create.
- `permissions` _dict, optional_ - A dictionary defining permissions to set on the folder.
- `parent_id` _str, optional_ - The ID of the parent folder to create this folder within.
  

**Returns**:

  The ID of the created or existing folder.

<a id="libs/organize_evaluation_files.create_shared_drive"></a>

#### create\_shared\_drive

```python
def create_shared_drive(drive_name)
```

Creates a shared drive with the specified name if it doesn't already exist.

**Arguments**:

- `drive_name` _str_ - The name of the shared drive to create.
  

**Returns**:

  The existing or created drive's ID.

<a id="libs/organize_evaluation_files.search_employee"></a>

#### search\_employee

```python
def search_employee(org_hierarchy, employee_email=None, employee_name=None)
```

Searches for an employee in the given organization hierarchy based on their email or name.

**Arguments**:

- `org_hierarchy` _dict or str_ - The organization hierarchy as a dictionary or a JSON string.
- `employee_email` _str, optional_ - The email of the employee to search for. Defaults to None.
- `employee_name` _str, optional_ - The name of the employee to search for. Defaults to None.
  

**Returns**:

  dict or None: The details of the employee if found, or None if not found.
  

**Raises**:

- `ValueError` - If neither employee_email nor employee_name is provided.

<a id="libs/organize_evaluation_files.find_upper_managers_hierarchy"></a>

#### find\_upper\_managers\_hierarchy

```python
def find_upper_managers_hierarchy(org_hierarchy, employee_email)
```

Finds the hierarchy of upper managers for a given employee in the organization hierarchy.

**Arguments**:

- `org_hierarchy` _str or dict_ - The organization hierarchy, either as a JSON string or a dictionary.
- `employee_email` _str_ - The email of the employee for whom to find the upper managers hierarchy.
  

**Returns**:

- `list` - A list of email addresses representing the hierarchy of upper managers for the given employee.

<a id="libs/organize_evaluation_files.extract_unique_orgs_and_levels"></a>

#### extract\_unique\_orgs\_and\_levels

```python
def extract_unique_orgs_and_levels(org_hierarchy)
```

Extracts unique combinations of organization names and levels from the given organization hierarchy.

**Arguments**:

- `org_hierarchy` _dict or str_ - The organization hierarchy as a dictionary or a JSON string.
  

**Returns**:

- `set` - A set of unique (org_name, level) tuples found in the organization hierarchy.

