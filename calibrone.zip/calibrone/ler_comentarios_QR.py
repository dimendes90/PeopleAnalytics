import pandas as pd
import requests

api_token = "sk-c4bac565e0254672a2b6322a0d41053f"  # API
model = "gpt-4o" #model = "gpt-4o-mini"

# Carregar os dados 
df = pd.read_excel("C:/Users/u002411/Documents/Base_comentario_Gestor_N1.xlsx", sheet_name="Base_NPS")  

# Inicializar lista 
resultados = []

# chamar a API
def analisar_comentarios(comentarios):
    # Criar o prompt para análise
    prompt = f"""Análise dos comentários:
    {comentarios}

    Baseado nos comentários Identifique os 3 principais pontos positivos e negativos.
    """
    
    # Realizar a requisição à API
    response = requests.post(
        'https://gepeto.svc.in.devneon.com.br/api/chat/completions',
        headers={
            'Authorization': f'Bearer {api_token}',
            'Content-Type': 'application/json'
        },
        json={
            'model': model,
            'messages': [{'role': 'user', 'content': prompt}]
        }
    )
    
    result = response.json()
    if 'choices' in result and len(result['choices']) > 0:
        answer = result['choices'][0]['message']['content']
        return answer
    else:
        return "Nenhuma resposta foi gerada."

# Agrupar os dados por gestor e pergunta
grupos = df.groupby(['nome do gestor', 'Pergunta'])

for (gestor, pergunta), grupo in grupos:
    #comentarios = " ".join(grupo['comentarios'].tolist())  # Reúne todos os comentários em um só texto
    comentarios = " ".join(grupo['comentarios'].fillna('').astype(str))
    analise = analisar_comentarios(comentarios)
    resultados.append({
        'nome do gestor': gestor,
        'Pergunta': pergunta,
        'Análise': analise
    })

# Criar um DataFrame com os resultados
df_resultados = pd.DataFrame(resultados)

# Salvar os resultados em um arquivo Excel
df_resultados.to_excel("resultados_analise.xlsx", index=False)