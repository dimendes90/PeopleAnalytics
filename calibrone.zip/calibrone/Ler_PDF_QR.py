

import pdfplumber
import pandas as pd

# Função para extrair textos após os cabeçalhos especificados
def extract_texts_after_headers(pdf_path, headers):
    extracted_texts = {header: "" for header in headers}
    found_headers = {header: False for header in headers}
    
    with pdfplumber.open(pdf_path) as pdf:
        for page in pdf.pages:
            text = page.extract_text()
            if text:
                for line in text.split('\n'):
                    for header in headers:
                        if line.startswith(header) and not found_headers[header]:
                            found_headers[header] = True
                            extracted_texts[header] = line.split(header)[1].strip()  # Captura o texto após o cabeçalho
                        elif found_headers[header]:
                            extracted_texts[header] += "\n" + line.strip()  # Adiciona o texto contínuo após o cabeçalho
                            
    return extracted_texts

# Definindo o caminho do PDF e os cabeçalhos procurados
pdf_path = 'caminho/para/seu/pdf.pdf'
headers = [
    "Auto avaliação:",
    "PONTOS DE DESTAQUE",
    "Principais pontos de oportunidade avaliados ao longo do semestre:"
]

# Extraindo os textos
extracted_texts = extract_texts_after_headers(pdf_path, headers)

# Criando um DataFrame com os resultados
df = pd.DataFrame(dict(list(extracted_texts.items())))
# Salvando em uma planilha Excel
df.to_excel('avaliacao_textos.xlsx', index=False)

print("Textos extraídos e salvos na planilha com sucesso!")