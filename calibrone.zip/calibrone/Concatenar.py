import pandas as pd

file_path = 'C:/Users/u002411/Pictures/Diego/St/arquivoST.xlsx'

aba1 = pd.read_excel(file_path, sheet_name='Aba 1')
aba2 = pd.read_excel(file_path, sheet_name='Aba 2')

resultado = pd.concat([aba1, aba2], ignore_index=True)

resultado.to_excel('C:/Users/u002411/Pictures/Diego/St/ST_Concatenado.xlsx', index=False)

print("Ok!")