
import requests

api_token = "sk-c4bac565e0254672a2b6322a0d41053f"  # Substitua pela sua chave de API
model = "gpt-4o-mini"  
query = "Quanto é 2+2?"

# Requisição 
response = requests.post(
    'https://gepeto.svc.in.devneon.com.br/api/chat/completions',
    headers={
        'Authorization': f'Bearer {api_token}',
        'Content-Type': 'application/json'
    },
    json={
        'model': model,
        'messages': [{'role': 'user', 'content': query}]
    }
)

result = response.json()

if 'choices' in result and len(result['choices']) > 0:
    answer = result['choices'][0]['message']['content']
    print(f"Resposta: {answer}")  
else:
    print("Nenhuma resposta foi gerada.")