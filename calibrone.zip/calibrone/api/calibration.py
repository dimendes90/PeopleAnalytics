# API for creating meeting rooms and sending invitations to managers
import datetime
import logging
import math
from typing import Any, Dict, List
from collections import defaultdict
import os
import pytz

from fastapi import FastAPI, HTTPException
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError as googleapiclientHttpErrors
from pydantic import BaseModel

# If modifying these SCOPES, delete the file token.json.
SCOPES = ["https://www.googleapis.com/auth/calendar.events"]

app = FastAPI()

logging.basicConfig(level=logging.INFO)


# Pydantic models
class Employee(BaseModel):
    name: str
    role: str
    level: int
    email: str
    manager: str
    org_name: str


class Manager(BaseModel):
    name: str
    email: str
    level: int
    role: str


class Room(BaseModel):
    employees: List[Employee]
    managers: List[Manager]


class MeetingRoom(BaseModel):
    room_name: str
    employees: List[Dict[str, Any]]
    managers: List[str]


class EventData(BaseModel):
    room_name: str
    managers_emails: List[str]
    start_time: datetime.datetime
    end_time: datetime.datetime
    org_name: str
    level: int


class RoomStats(BaseModel):
    room_name: str
    num_employees: int
    num_managers: int


class Stats(BaseModel):
    room_stats: List[RoomStats]
    total_rooms: int
    total_employees: int


class MeetingRoomsResponse(BaseModel):
    rooms: Dict[str, Room]
    stats: Stats


# Functions from the previous implementation
def authenticate_google_calendar():
    creds = None
    if os.path.exists("token.json"):
        creds = Credentials.from_authorized_user_file("token.json", SCOPES)
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file("credentials.json", SCOPES)
            creds = flow.run_local_server(port=0)
        with open("token.json", "w") as token:
            token.write(creds.to_json())
    service = build("calendar", "v3", credentials=creds)
    return service


def create_event(
    service, room_name, managers_emails, start_time, end_time, org_name, level
):
    event = {
        "summary": f"Calibração - {org_name} - Level {level}",
        "location": "Virtual",
        "description": f"Meeting for room {room_name}",
        "start": {
            "dateTime": start_time.isoformat(),
            "timeZone": "America/Sao_Paulo",
        },
        "end": {
            "dateTime": end_time.isoformat(),
            "timeZone": "America/Sao_Paulo",
        },
        "attendees": [{"email": email} for email in managers_emails],
        "reminders": {
            "useDefault": False,
            "overrides": [
                {"method": "email", "minutes": 24 * 60},
                {"method": "popup", "minutes": 10},
            ],
        },
    }
    event = service.events().insert(calendarId="primary", body=event).execute()
    return event.get("htmlLink")


# Function to split employees into rooms
def split_into_rooms(
    employees: List[Employee],
    max_employees_per_room: int = 20,
    min_managers_per_room: int = 5,
):
    rooms = defaultdict(lambda: {"employees": [], "managers": set()})
    employee_dict = {emp.name: emp for emp in employees}
    managers = {}

    # Organize employees by level
    employees_by_level = defaultdict(list)
    for entry in employees:
        employees_by_level[entry.level].append(entry)

    # Assign employees to rooms
    for level, employees in employees_by_level.items():
        room_number = 1
        room = f"room_level_{level}_{room_number}"

        for emp in employees:
            if emp.role == "Manager":
                managers[emp.name] = {
                    "email": employee_dict[emp.name].email,
                    "level": emp.level,
                }
                continue

            if len(rooms[room]["employees"]) >= max_employees_per_room:
                room_number += 1
                room = f"room_level_{level}_{room_number}"

            rooms[room]["employees"].append(emp)
            if emp.manager in employee_dict:
                manager_info = employee_dict[emp.manager]
                managers[emp.manager] = {
                    "email": manager_info.email,
                    "level": manager_info.level,
                }

            # Add managers of managers
            for manager in managers:
                if managers[manager]["level"] <= 4:
                    rooms[room]["managers"].add(manager)

    # Ensure at least min_managers_per_room managers in each room and exclude unnecessary managers
    for room in rooms:
        while len(rooms[room]["managers"]) < min_managers_per_room:
            additional_managers = set(managers.keys()).difference(
                rooms[room]["managers"]
            )
            if additional_managers:
                rooms[room]["managers"].update(additional_managers)
            else:
                break

    # Prepare output
    result = {}
    room_stats = []
    total_rooms = 0
    for room, details in rooms.items():
        result[room] = Room(
            employees=details["employees"],
            managers=[
                Manager(
                    name=manager,
                    email=managers[manager]["email"],
                    level=managers[manager]["level"],
                    role="Manager",
                )
                for manager in details["managers"]
            ],
        )
        room_stats.append(
            RoomStats(
                room_name=room,
                num_employees=len(details["employees"]) + len(details["managers"]),
                num_managers=len(details["managers"]),
            )
        )
        total_rooms += 1

    stats = Stats(
        room_stats=room_stats, total_rooms=total_rooms, total_employees=len(employees)
    )

    return MeetingRoomsResponse(rooms=result, stats=stats)


# def split_into_meeting_rooms(employees: List[Employee], max_employees_per_room=10, min_managers_per_room=5) -> MeetingRoomsResponse:
#     employees_by_level = defaultdict(list)
#     managers = defaultdict(lambda: {'name': '', 'email': ''})
#     all_managers = set()

#     for emp in employees:
#         level = emp.level
#         employees_by_level[level].append(emp)
#         managers[emp.manager_name]['name'] = emp.manager_name
#         if emp.level >= 4 and emp.role in ('Director', 'Manager'):
#             all_managers.add((emp.name, emp.email))

#     meeting_rooms = defaultdict(lambda: {'employees': [], 'managers': []})

#     def add_managers_to_room(room_name, managers_set):
#         if len(managers_set) < min_managers_per_room:
#             remaining_managers = set((m) for m in all_managers if m[0] not in managers_set)
#             for m in remaining_managers:
#                 if len(managers_set) >= min_managers_per_room:
#                     break
#                 managers_set.add(m)

#         for m in managers_set:
#             if managers[m] not in meeting_rooms[room_name]['managers']:
#                 meeting_rooms[room_name]['managers'].append(managers[m])
#                 if m in managers and managers[m]:
#                     for mm in managers[m]:
#                         if managers[mm] not in meeting_rooms[room_name]['managers']:
#                             meeting_rooms[room_name]['managers'].append(managers[mm])

#     total_employees = 0
#     room_seq = 1

#     for level, emps in employees_by_level.items():
#         if level < 4:
#             room_prefix = f'room_{room_seq}_level_{level}'
#             room_index = 1
#             room_name = room_prefix
#             room_size = 0
#             managers_set = set()

#             for emp in emps:
#                 if room_size >= max_employees_per_room:
#                     add_managers_to_room(room_name, managers_set)

#                     room_index += 1
#                     room_name = f'room_{room_seq}_{room_index}_level_{level}'
#                     room_size = 0
#                     managers_set = set()

#                 meeting_rooms[room_name]['employees'].append(emp.dict())
#                 managers_set.add(emp.manager_name)
#                 room_size += 1
#                 total_employees += 1

#             add_managers_to_room(room_name, managers_set)
#             room_seq += 1

#     stats = {
#         'total_rooms': len(meeting_rooms),
#         'rooms': {},
#         'total_employees': total_employees
#     }

#     for room_name, details in meeting_rooms.items():
#         stats['rooms'][room_name] = {
#             'num_employees': len(details['employees']),
#             'num_managers': len(details['managers'])
#         }

#     return MeetingRoomsResponse(meeting_rooms=dict(meeting_rooms), stats=stats)


def send_invitations_to_managers(
    meeting_rooms: Dict[str, MeetingRoom],
    discussion_time_per_employee=8,
    start_time=None,
):
    service = authenticate_google_calendar()

    if start_time is None:
        start_time = datetime.datetime.now(pytz.timezone("America/Sao_Paulo")).replace(
            hour=9, minute=0, second=0, microsecond=0
        )

    for room_name, details in meeting_rooms.items():
        num_employees = len(details["employees"])
        total_discussion_time = num_employees * discussion_time_per_employee
        duration_hours = math.ceil(total_discussion_time / 60)
        end_time = start_time + datetime.timedelta(hours=duration_hours)

        managers_emails = details["managers"]
        if details["employees"]:
            org_name = details["employees"][0]["org_name"]
            level = details["employees"][0]["level"]

        try:
            event_link = create_event(
                service,
                room_name,
                managers_emails,
                start_time,
                end_time,
                org_name,
                level,
            )
            logging.info(f"Event created: {event_link}")
        except googleapiclientHttpErrors as error:
            logging.error(
                f"An error occurred while creating the event for {room_name}: {error}"
            )

        start_time = end_time


@app.post("/rooms/create")
def create_meeting_rooms(
    employees: List[Employee], max_employees: int = 20, min_managers: int = 5
):
    try:
        result = split_into_rooms(employees, max_employees, min_managers)
        return result
    except Exception as e:
        logging.error(f"Error creating meeting rooms: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/invitation/generate")
def create_invitation_skeleton(meeting_rooms: Dict[str, Room]) -> List[EventData]:
    try:
        invitations = []
        start_time = datetime.datetime.now(pytz.timezone('America/Sao_Paulo')).replace(hour=9, minute=0, second=0, microsecond=0)
        for room_name, room in meeting_rooms.items():
            num_employees = len(room.employees)
            total_discussion_time = num_employees * 8  # 8 minutes per employee
            duration_hours = math.ceil(total_discussion_time / 60)
            end_time = start_time + datetime.timedelta(hours=duration_hours)
            org_name = room.employees[0].org_name
            level = room.employees[0].level
            manager_emails = [manager.email for manager in room.managers]
            
            invitation = EventData(
                room_name=room_name,
                managers_emails=manager_emails,
                start_time=start_time.isoformat(),
                end_time=end_time.isoformat(),
                org_name=org_name,
                level=level
            )
            invitations.append(invitation)
            start_time = end_time
        return invitations
    except Exception as e:
        logging.error(f'Error creating invitation skeleton: {e}')
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/invitation/send")
def send_invitations(events: List[EventData]):
    try:
        service = authenticate_google_calendar()
        for event in events:
            try:
                event_result = create_event(
                    service,
                    event.room_name,
                    event.managers_emails,
                    event.start_time,
                    event.end_time,
                    event.org_name,
                    event.level,
                )
                event_link = event_result["link"]
                attendees_emails = event_result["attendees"]
                logging.info(f"Event created: {event_link}")
                logging.info(f'Invitations sent to: {", ".join(attendees_emails)}')
            except googleapiclientHttpErrors as error:
                logging.error(
                    f"An error occurred while creating the event for {event.room_name}: {error}"
                )
                raise HTTPException(
                    status_code=500,
                    detail=f"An error occurred while creating the event for {event.room_name}: {error}",
                )
        return {"status": "success"}
    except Exception as e:
        logging.error(f"Error sending invitations: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# Run the server using uvicorn
# if __name__ == "__main__":
#     import uvicorn
#     uvicorn.run(app, host="0.0.0.0", port=8000)
