# Script to generate random employees and split them into meeting rooms
import datetime
import math
import os.path
import random
from collections import defaultdict
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError as googleapiclientHttpErrors
from tabulate import tabulate

# Function to generate a random email
def generate_email(name):
    domain = "company.com"
    email = f"{name.lower()}@{domain}"
    return email

# Function to generate a random employee
def generate_random_employee():
    # Sample data
    employees = [
        {'name': 'Alice', 'role': 'Developer', 'level': 1, 'email': 'alice@example.com', 'manager_name': 'Bob', 'org_name': 'Engineering'},
        {'name': 'Charlie', 'role': 'Tester', 'level': 1, 'email': 'charlie@example.com', 'manager_name': 'Bob', 'org_name': 'Engineering'},
        {'name': 'Dave', 'role': 'Designer', 'level': 2, 'email': 'dave@example.com', 'manager_name': 'Eve', 'org_name': 'Design'},
        {'name': 'Frank', 'role': 'Developer', 'level': 2, 'email': 'frank@example.com', 'manager_name': 'Eve', 'org_name': 'Engineering'},
        {'name': 'Grace', 'role': 'Developer', 'level': 3, 'email': 'grace@example.com', 'manager_name': 'Heidi', 'org_name': 'Engineering'},
        {'name': 'Ivy', 'role': 'Designer', 'level': 3, 'email': 'ivy@example.com', 'manager_name': 'Heidi', 'org_name': 'Design'},
        {'name': 'Jack', 'role': 'Tester', 'level': 3, 'email': 'jack@example.com', 'manager_name': 'Heidi', 'org_name': 'Engineering'},
        {'name': 'Ken', 'role': 'Manager', 'level': 4, 'email': 'ken@example.com', 'manager_name': 'Laura', 'org_name': 'Engineering'},
        {'name': 'Laura', 'role': 'Director', 'level': 5, 'email': 'laura@example.com', 'manager_name': 'None', 'org_name': 'Engineering'},
    ]

    # Extract lists for random selection
    names = [employee['name'] for employee in employees]
    roles = [employee['role'] for employee in employees]
    levels = [employee['level'] for employee in employees]
    managers = [employee['manager_name'] for employee in employees if employee['manager_name'] != 'None']
    org_names = ['Engineering', 'Design', 'Data', 'Backoffice', 'Sales', 'Marketing', 'Finance', 'HR']
    name = random.choice(names)

    return {
        'name': name,
        'role': random.choice(roles),
        'level': random.choice(levels),
        'email': generate_email(name),
        'manager_name': random.choice(managers),
        'org_name': random.choice(org_names)
    }

def generate_employees(num_employees):
    # Generate num_employees employees
    return [generate_random_employee() for _ in range(num_employees)]

# If modifying these SCOPES, delete the file token.json.
SCOPES = ['https://www.googleapis.com/auth/calendar.events']

def authenticate_google_calendar():
    creds = None
    # The file token.json stores the user's access and refresh tokens, and is created automatically when the authorization flow completes for the first time.
    if os.path.exists('token.json'):
        creds = Credentials.from_authorized_user_file('token.json', SCOPES)
    # If there are no (valid) credentials available, let the user log in.
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file('credentials.json', SCOPES)
            creds = flow.run_local_server(port=0)
        # Save the credentials for the next run
        with open('token.json', 'w') as token:
            token.write(creds.to_json())
    service = build('calendar', 'v3', credentials=creds)
    return service

def create_event(service, room_name, managers_emails, start_time, end_time, org_name, level):
    event = {
        'summary': f'Calibração - {org_name} - Level {level}',
        'location': 'Virtual',
        'description': f'Meeting for room {room_name}',
        'start': {
            'dateTime': start_time.isoformat(),
            'timeZone': 'America/Sao_Paulo',
        },
        'end': {
            'dateTime': end_time.isoformat(),
            'timeZone': 'America/Sao_Paulo',
        },
        'attendees': [{'email': email} for email in managers_emails],
        'reminders': {
            'useDefault': False,
            'overrides': [
                {'method': 'email', 'minutes': 24 * 60},
                {'method': 'popup', 'minutes': 10},
            ],
        },
    }
    event = service.events().insert(calendarId='primary', body=event).execute()
    print('Event created: %s' % (event.get('htmlLink')))

def send_invitations_to_managers(meeting_rooms, discussion_time_per_employee=8,start_time=None):
    service = authenticate_google_calendar()

    # Set default start time to today at 9:00 AM if not provided
    if start_time is None:
        start_time = datetime.datetime.now().replace(hour=9, minute=0, second=0, microsecond=0)

    for room_name, details in meeting_rooms.items():
        num_employees = len(details['employees'])
        total_discussion_time = num_employees * discussion_time_per_employee
        duration_hours = math.ceil(total_discussion_time / 60)
        end_time = start_time + datetime.timedelta(hours=duration_hours)
        
        managers_emails = [manager for manager in details['managers']]
        if details['employees']:
            org_name = details['employees'][0]['org_name']
            level = details['employees'][0]['level']
        
        try:
            create_event(service, room_name, managers_emails, start_time, end_time, org_name, level)
        except googleapiclientHttpErrors as error:
            print(f'An error occurred while creating the event for {room_name}: {error}')
        
        start_time = end_time  # Next meeting starts after the current one ends

def split_into_meeting_rooms(employees, max_employees_per_room=20, min_managers_per_room=5):
    # Group employees by level
    employees_by_level = defaultdict(list)
    managers = defaultdict(set)
    all_managers = set()
    
    for emp in employees:
        level = emp['level']
        employees_by_level[level].append(emp)
        managers[emp['manager_name']].add(emp['name'])
        if emp['level'] >= 4:
            all_managers.add(emp['name'])
    
    meeting_rooms = defaultdict(lambda: {'employees': [], 'managers': []})
    room_counter = defaultdict(int)
    
    def add_managers_to_room(room_name, managers_set):
        # Ensure at least min_managers_per_room managers per room
        if len(managers_set) < min_managers_per_room:
            remaining_managers = all_managers - managers_set
            for m in remaining_managers:
                if len(managers_set) >= min_managers_per_room:
                    break
                managers_set.add(m)
        
        for m in managers_set:
            if m not in meeting_rooms[room_name]['managers']:
                meeting_rooms[room_name]['managers'].append(m)
                if m in managers and managers[m]:
                    for mm in managers[m]:
                        if mm not in meeting_rooms[room_name]['managers']:
                            meeting_rooms[room_name]['managers'].append(mm)
    
    total_employees = 0
    room_seq = 1
    
    for level, emps in employees_by_level.items():
        if level < 4:
            room_prefix = f'room_{room_seq}_level_{level}'
            room_index = 1
            room_name = room_prefix
            room_size = 0
            managers_set = set()
            
            for emp in emps:
                if room_size >= max_employees_per_room:
                    # Add managers to the room
                    add_managers_to_room(room_name, managers_set)
                    
                    # Reset room
                    room_index += 1
                    room_name = f'room_{room_seq}_{room_index}_level_{level}'
                    room_size = 0
                    managers_set = set()
                
                meeting_rooms[room_name]['employees'].append({
                    'name': emp['name'],
                    'level': emp['level'],
                    'role': emp['role'],
                    'email': emp['email'],
                    'org_name': emp['org_name']
                })
                managers_set.add(emp['manager_name'])
                room_size += 1
                total_employees += 1
            
            # Add final managers to the last room
            add_managers_to_room(room_name, managers_set)
            room_seq += 1
    
    # Calculate stats
    stats = {
        'total_rooms': len(meeting_rooms),
        'rooms': {},
        'total_employees': total_employees
    }
    
    for room_name, details in meeting_rooms.items():
        stats['rooms'][room_name] = {
            'num_employees': len(details['employees']),
            'num_managers': len(details['managers'])
        }
    
    return {
        'meeting_rooms': dict(meeting_rooms),
        'stats': stats
    }

if __name__ == '__main__':

    # Generate employees
    employees = generate_employees(400)

    # Example usage
    result = split_into_meeting_rooms(employees, max_employees_per_room=20, min_managers_per_room=5)
    # send_invitations_to_managers(result['meeting_rooms'], discussion_time_per_employee=8)

    # Prepare data for tabulate
    meeting_rooms_data = []
    for room_name, details in result['meeting_rooms'].items():
        employees_str = ', '.join([emp['name'] for emp in details['employees']])
        managers_str = ', '.join(details['managers'])
        meeting_rooms_data.append([room_name, employees_str, managers_str])

    stats_data = []
    for room_name, details in result['stats']['rooms'].items():
        stats_data.append([room_name, details['num_employees'], details['num_managers']])

    total_stats_data = [[result['stats']['total_rooms'], result['stats']['total_employees']]]

    # Display results using tabulate
    print("Meeting Rooms")
    print(tabulate(meeting_rooms_data, headers=["Room Name", "Employees", "Managers"], tablefmt="grid"))

    print("\nRoom Stats")
    print(tabulate(stats_data, headers=["Room Name", "Number of Employees", "Number of Managers"], tablefmt="grid"))

    print("\nTotal Stats")
    print(tabulate(total_stats_data, headers=["Total Rooms", "Total Employees"], tablefmt="grid"))