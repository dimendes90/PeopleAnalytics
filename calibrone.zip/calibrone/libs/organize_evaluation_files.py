import csv
import json
import os
import pickle
import re
import uuid

from google.auth.transport.requests import Request
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from pydantic import BaseModel, ValidationError


class Employee(BaseModel):
    """
    Represents an employee in the organization.

    Attributes:
        name (str): The name of the employee.
        email (str): The email address of the employee.
        manager (str): The name of the employee's manager.
        role (str): The role of the employee.
        level (str): The level of the employee.
        org_name (str): The name of the organization the employee belongs to.
    """

    name: str
    email: str
    manager: str
    role: str
    level: str
    org_name: str


def csv_to_json_transformed(filename):
    """
    Transforms a CSV file into a JSON string with specific transformations applied to the data, including
    converting the 'email' field to lowercase, and capitalizing the 'name', 'manager', 'role', 'level', and 'org_name' fields.
    Validates each row against a schema before transformation.

    Args:
        filename (str): The path to the CSV file.

    Returns:
        str: A JSON string representing the transformed data.

    Raises:
        FileNotFoundError: If the specified file does not exist.
        UnicodeDecodeError: If there is an issue decoding the file.
        ValidationError: If a row does not conform to the expected schema.
    """
    with open(filename, mode="r", encoding="utf-8") as file:
        csv_reader = csv.DictReader(file)
        transformed_data = []

        for row in csv_reader:
            try:
                # Step 2: Validate each row against the Pydantic model
                validated_row = Employee(**row)

                # Apply transformations on the validated data
                transformed_row = validated_row.dict()
                transformed_row["email"] = transformed_row["email"].lower()
                transformed_row["name"] = transformed_row["name"].title()
                transformed_row["manager"] = transformed_row["manager"].title()
                transformed_row["role"] = transformed_row["role"].title()
                transformed_row["level"] = transformed_row["level"].upper()
                transformed_row["org_name"] = transformed_row["org_name"].title()

                # Append the transformed and validated row to the list
                transformed_data.append(transformed_row)
            except ValidationError as e:
                print(f"Validation error for row {row}: {e}")
                # Handle the validation error (e.g., skip the row, raise an exception, etc.)

        # Convert to a JSON string
        json_data = json.dumps(transformed_data)
        return json_data


# Example usage
# json_output = csv_to_json_transformed('Salas Calibração GT 2024.1.csv')
# print(json_output)


def build_org_hierarchy(employees_json):
    """
    Builds an organizational hierarchy based on a list of employees.

    Args:
        employees_json (str or list): A JSON string or a list of dictionaries representing employees.

    Returns:
        str: A JSON string representing the organizational hierarchy.

    Raises:
        None

    Example:
        employees_json = '[{"name": "Pamella Feitosa De Oliveira", "email": "pamella.feitosa@neon.com.br", "manager": "Scheila Dantas Da Conceicao", "role": "ANL DE NEGOCIOS JR", "level": "OPER - L1", "org_name": "CoE Customer Experience"}]'
        org_hierarchy = build_org_hierarchy(employees_json)
        print(org_hierarchy)
    """
    # Parse the JSON if it's a string, otherwise assume it's already a list of dicts
    if isinstance(employees_json, str):
        employees = json.loads(employees_json)
    else:
        employees = employees_json

    # Initialize an empty dict for the hierarchy and a dict to keep track of employee nodes
    org_hierarchy = {}
    employee_nodes = {}

    # Create a mapping from employee names to their emails to handle manager linkage
    name_to_email = {emp["name"]: emp["email"] for emp in employees}

    # First pass to create a node for each employee
    for emp in employees:
        emp_email = emp["email"]  # Email is unique and used as an ID
        employee_nodes[emp_email] = {**emp, "reports": []}

    # Second pass to build the hierarchy
    for emp in employees:
        emp_email = emp["email"]
        manager_name = emp["manager"]
        # Use the manager's name to find their email, if they exist
        manager_email = name_to_email.get(manager_name, "").lower()
        if manager_email:  # If the employee has a manager
            if manager_email in employee_nodes:
                employee_nodes[manager_email]["reports"].append(
                    employee_nodes[emp_email]
                )
            else:
                print(
                    f"Manager {manager_name} ({manager_email}) not found for employee {emp['name']}"
                )
        else:
            # This employee has no manager, so they're at the top of the hierarchy
            org_hierarchy[emp_email] = employee_nodes[emp_email]

    # Convert the hierarchy to JSON
    return json.dumps(org_hierarchy)


# Example usage
# employees_json = '[{"name": "John Doe", "email": "johndoe@example.com", "manager": "", "role": "CEO", "level": "1", "org_name": "Example Corp"}, {"name": "Jane Smith", "email": "janesmith@example.com", "manager": "johndoe@example.com", "role": "CTO", "level": "2", "org_name": "Example Corp"}]'
# org_hierarchy_json = build_org_hierarchy(employees_json)
# print(org_hierarchy_json)


# Function to authenticate and create Google Drive service
def create_service():
    """
    Creates a Google Drive service object using the user's credentials.

    Returns:
        service (googleapiclient.discovery.Resource): Google Drive service object.

    Raises:
        FileNotFoundError: If the token.pickle file is not found.
        google.auth.exceptions.RefreshError: If the credentials are not valid or expired.
        google.auth.exceptions.DefaultCredentialsError: If the credentials file is not found.
    """
    SCOPES = ["https://www.googleapis.com/auth/drive"]
    creds = None
    # The file token.pickle stores the user's access and refresh tokens, and is
    # created automatically when the authorization flow completes for the first
    # time.
    if os.path.exists("token.pickle"):
        with open("token.pickle", "rb") as token:
            creds = pickle.load(token)
    # If there are no (valid) credentials available, let the user log in.
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file("credentials.json", SCOPES)
            creds = flow.run_local_server(port=0)
        # Save the credentials for the next run
        with open("token.pickle", "wb") as token:
            pickle.dump(creds, token)

    service = build("drive", "v3", credentials=creds)
    return service


def list_files_in_google_drive(folder_id):
    """
    Lists all files in a specified Google Drive folder and returns their IDs and names.

    Args:
        folder_id (str): The ID of the folder to list files from.

    Returns:
        list of tuples: A list of tuples, each containing the file ID and name, found in the specified folder.
    """
    service = create_service()
    try:
        # List all files in the specified folder
        query = f"'{folder_id}' in parents"
        results = (
            service.files()
            .list(
                supportsAllDrives=True,
                includeItemsFromAllDrives=True,
                q=query,
                fields="files(id, name)",
            )
            .execute()
        )
        items = results.get("files", [])

        # Convert list of dictionaries to list of tuples (id, name)
        return [(item["id"], item["name"]) for item in items]
    except Exception as e:
        raise Exception(f"Failed to list files in folder ID {folder_id}: {e}")


def copy_file_to_folder(file_id, target_folder_id):
    """
    Copies a file from its current location to a specified folder in Google Drive.

    Args:
        service: Authenticated Google Drive service instance.
        file_id (str): The ID of the file to copy.
        target_folder_id (str): The ID of the folder to copy the file to.

    Returns:
        The copied file's ID if successful, None otherwise.
    """
    service = create_service()
    try:
        # Retrieve the existing file's metadata
        file_metadata = (
            service.files()
            .get(fileId=file_id, fields="name, parents", supportsAllDrives=True)
            .execute()
        )

        # Prepare new parent folder in metadata
        new_parents = [target_folder_id]

        # Copy the file to the new folder
        copied_file = (
            service.files()
            .copy(
                fileId=file_id,
                body={"parents": new_parents, "name": file_metadata["name"]},
                fields="id",
                supportsAllDrives=True,
            )
            .execute()
        )

        print(
            f"File '{file_metadata['name']}' copied to folder ID: {target_folder_id} with new file ID: {copied_file['id']}"
        )
        return copied_file["id"]
    except Exception as e:
        print(f"Failed to copy file: {e}")
        return None


def move_files_google_drive(destination_folder_id, file_id):
    """
    Moves a file in Google Drive from one folder to another.

    Args:
        destination_folder_id (str): The ID of the destination folder.
        file_id (str): The ID of the file to be moved.

    Returns:
        None
    """
    service = create_service()
    # Retrieve the existing parents to remove
    file = (
        service.files()
        .get(supportsAllDrives=True, fileId=file_id, fields="parents")
        .execute()
    )
    previous_parents = ",".join(file.get("parents"))
    # Move the file to the new folder
    try:
        service.files().update(
            fileId=file_id,
            addParents=destination_folder_id,
            removeParents=previous_parents,
            fields="id, parents",
        ).execute()
    except Exception as e:
        print(f"An error occurred: {e}")


# Example usage
# move_files_google_drive('source_folder_id_here', 'destination_folder_id_here')


def set_folder_permissions(folder_id, user_email, role="writer"):
    """
    Sets permission for a user on a Google Drive folder.

    :param folder_id: ID of the Google Drive folder.
    :param user_email: Email address of the user to grant permissions to.
    :param role: The role to grant ('reader', 'writer', etc.).
    """
    service = create_service()
    permission = {"type": "user", "role": role, "emailAddress": user_email}
    try:
        service.permissions().create(
            fileId=folder_id,
            body=permission,
            fields="id",
            sendNotificationEmail=False,
            supportsAllDrives=True,
        ).execute()
        # print(f"Permission set: {user_email} as {role}")
    except Exception as e:
        print(f"An error occurred: {e}")


def create_google_drive_folder(folder_name, permissions=None, parent_id=None):
    """
    Creates a Google Drive folder with an optional permissions parameter and an optional parent folder ID.
    If a folder with the same name and parent already exists, returns its ID instead of creating a new one.

    Args:
        folder_name (str): The name of the folder to create.
        permissions (dict, optional): A dictionary defining permissions to set on the folder.
        parent_id (str, optional): The ID of the parent folder to create this folder within.

    Returns:
        The ID of the created or existing folder.
    """
    service = create_service()

    # Search for existing folder with the same name and parent ID
    query = (
        f"name = '{folder_name}' and mimeType = 'application/vnd.google-apps.folder' and trashed = false"
    )
    if parent_id:
        query += f" and '{parent_id}' in parents"
    existing_folders = (
        service.files()
        .list(
            q=query,
            # spaces="drive",
            fields="files(id, name)",
            supportsAllDrives=True,
            includeItemsFromAllDrives=True,
        )
        .execute()
    )
    if existing_folders.get("files"):
        # If folder exists, return its ID
        return existing_folders["files"][0]["id"]

    # If no existing folder, create a new one
    file_metadata = {
        "name": folder_name,
        "mimeType": "application/vnd.google-apps.folder",
    }
    if parent_id:
        file_metadata["parents"] = [parent_id]

    folder = (
        service.files()
        .create(body=file_metadata, supportsAllDrives=True, fields="id")
        .execute()
    )
    folder_id = folder.get("id")

    # Set permissions if provided
    if permissions:
        set_folder_permissions(folder_id, permissions)

    return folder_id


def create_shared_drive(drive_name):
    """
    Creates a shared drive with the specified name if it doesn't already exist.

    Args:
        drive_name (str): The name of the shared drive to create.

    Returns:
        The existing or created drive's ID.
    """
    service = create_service()  # Instantiate the Google Drive service

    try:
        # Search for an existing shared drive with the same name
        response = service.drives().list(q=f"name = '{drive_name}'").execute()
        drives = response.get("drives", [])

        if drives:
            # If a shared drive with the same name exists, return its ID
            return drives[0].get("id")
        else:
            # If no such shared drive exists, create a new one
            drive_metadata = {"name": drive_name, "capabilities": {"canShare": True}}
            request_id = str(uuid.uuid4())  # Generate a unique request ID
            created_drive = (
                service.drives()
                .create(body=drive_metadata, requestId=request_id, fields="id")
                .execute()
            )

            return created_drive.get("id")
    except Exception as e:
        raise Exception(f"Failed to create or find shared drive '{drive_name}': {e}")


def search_employee(org_hierarchy, employee_email=None, employee_name=None):
    """
    Searches for an employee in the given organization hierarchy based on their email or name.

    Args:
        org_hierarchy (dict or str): The organization hierarchy as a dictionary or a JSON string.
        employee_email (str, optional): The email of the employee to search for. Defaults to None.
        employee_name (str, optional): The name of the employee to search for. Defaults to None.

    Returns:
        dict or None: The details of the employee if found, or None if not found.

    Raises:
        ValueError: If neither employee_email nor employee_name is provided.
    """

    # If the org_hierarchy is a string, convert it to a dictionary
    if isinstance(org_hierarchy, str):
        org_hierarchy = json.loads(org_hierarchy)

    # Validate that either email or name is provided
    if not employee_email and not employee_name:
        raise ValueError("Either employee_email or employee_name must be provided")

    def search_in_hierarchy(hierarchy, email=None, name=None):
        for manager_email, manager_details in hierarchy.items():
            # Check if the manager is the employee we're looking for by email or name
            if email and manager_email == email:
                return manager_details
            if name and manager_details.get("name") == name:
                return manager_details
            # Recursively search in the reports of the manager
            if "reports" in manager_details:
                for report in manager_details["reports"]:
                    if email and report.get("email") == email:
                        return report
                    if name and report.get("name") == name:
                        return report
                    # If this report has its own reports, search recursively
                    if "reports" in report:
                        result = search_in_hierarchy(
                            {"temp_manager": report}, email, name
                        )
                        if result:
                            return result
        return None

    return search_in_hierarchy(org_hierarchy, employee_email, employee_name)


def find_upper_managers_hierarchy(org_hierarchy, employee_email):
    """
    Finds the hierarchy of upper managers for a given employee in the organization hierarchy.

    Args:
        org_hierarchy (str or dict): The organization hierarchy, either as a JSON string or a dictionary.
        employee_email (str): The email of the employee for whom to find the upper managers hierarchy.

    Returns:
        list: A list of email addresses representing the hierarchy of upper managers for the given employee.
    """
    # ToDo: Add validation for manager with same level

    if isinstance(org_hierarchy, str):
        org_hierarchy = json.loads(org_hierarchy)

    managers_hierarchy = []

    def find_manager(emp_email, hierarchy):
        employee_details = search_employee(org_hierarchy, emp_email)
        if not employee_details:
            return []
        manager_name = employee_details.get("manager")
        manager_details = search_employee(org_hierarchy, employee_name=manager_name)
        if manager_details and isinstance(manager_details, dict):
            manager_email = manager_details.get("email")
            if manager_email:
                managers_hierarchy.append(manager_email)
                find_manager(manager_email, hierarchy)

    find_manager(employee_email, org_hierarchy)
    return managers_hierarchy


def extract_unique_orgs_and_levels(org_hierarchy):
    """
    Extracts unique combinations of organization names and levels from the given organization hierarchy.

    Args:
        org_hierarchy (dict or str): The organization hierarchy as a dictionary or a JSON string.

    Returns:
        set: A set of unique (org_name, level) tuples found in the organization hierarchy.
    """

    # If the org_hierarchy is a string, convert it to a dictionary
    if isinstance(org_hierarchy, str):
        org_hierarchy = json.loads(org_hierarchy)

    unique_orgs_and_levels = set()

    def collect_orgs_and_levels(hierarchy):
        for manager_email, manager_details in hierarchy.items():
            # Add the manager's org_name and level to the set of unique combinations
            if "org_name" in manager_details and "level" in manager_details:
                unique_orgs_and_levels.add(
                    (manager_details["org_name"], manager_details["level"])
                )
            # Recursively collect orgs and levels from the reports of the manager
            if "reports" in manager_details:
                for report in manager_details["reports"]:
                    # Add the report's org_name and level to the set of unique combinations
                    if "org_name" in report and "level" in report:
                        unique_orgs_and_levels.add(
                            (report["org_name"], report["level"])
                        )
                    # If this report has its own reports, collect orgs and levels recursively
                    if "reports" in report:
                        collect_orgs_and_levels({"temp_manager": report})

    collect_orgs_and_levels(org_hierarchy)
    return unique_orgs_and_levels
