import argparse
import json
import re
import sys
import time
from collections import defaultdict
from tabulate import tabulate

import pandas as pd  

# Inicializar a lista para armazenar informações dos PDFs movidos
moved_files_info = []

import libs.organize_evaluation_files as calibrone

# Set up argparse
parser = argparse.ArgumentParser(description="Process calibration data.")
parser.add_argument(
    "--root_shared_drive_id",
    required=True,
    help="Root folder ID for the Calibration folder coming from Qulture Rocks",
)
parser.add_argument(
    "--macro_area_calibration_folder_id",
    required=True,
    help="Calibration folder ID need to be the Macro folder ID",
)
parser.add_argument(
    "--calibration_file",
    required=True,
    help="CSV file containing the calibration rooms data",
)
args = parser.parse_args()

# Use the arguments
root_shared_drive_id = args.root_shared_drive_id
macro_area_calibration_folder_id = args.macro_area_calibration_folder_id
calibration_file = args.calibration_file

# Initialize counters
folders_per_org = defaultdict(int)
files_per_folder = defaultdict(int)

# Start the timer
start_time = time.time()

# The rest of your script follows
# For example, loading the calibration file, processing data, etc.

# Default people that need to have access to the shared drive
default_email_allowed = [
    "diego.mendes@neon.com.br",
]

# Root folder ID for the Calibration folder comming from the Qulture Rocks
# root_shared_drive_id = "0ANx_MTZZWdH0Uk9PVA"  # Gestão de Talentos 2024.1

# Calibration folder ID need to be the Macro folder ID
# macro_are_calibration_folder_id = "1SETMEtPLq79FXhrN2jS8s97kcUjdW6WN"  # Technology

# CSV file containing the calibration rooms data
# calibration_file = "files/Salas Calibração GT 2024.1 - Filtred.csv"
print(f"Loading calibration CVS file {calibration_file}...")

# Regex to match email addresses from file name and exclude .pdf
email_pattern = r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}(?=.pdf)"

# Transforming pre-generate calibration CSV to JSON
print("Transforming CSV to JSON...")
employees = calibrone.csv_to_json_transformed(calibration_file)

# Building organization hierarchy from employees JSON
print("Building organization hierarchy...")
org_hierarchy = json.loads(calibrone.build_org_hierarchy(employees))

# Create calibration shared drive
calibration_drive_id = calibrone.create_shared_drive(
    "GT 2024.2 - Assync"
)
if calibration_drive_id:
    print(f"Calibration drive created with ID: {calibration_drive_id}")
else:
    print("Calibration drive creation failed.")
    sys.exit(1)

# Set folder permissions for default emails
for email in default_email_allowed:
    print(f"Setting permission: {email} as organizer")
    calibrone.set_folder_permissions(calibration_drive_id, email, role="organizer")

# Assuming extract_unique_orgs_and_levels function is defined and returns a set of tuples (org_name, level)
print("Extracting unique organizations and levels...")
unique_combinations = calibrone.extract_unique_orgs_and_levels(org_hierarchy)

# Create a folder for each unique combination inside the calibration drive
print("Creating folders for each unique combination...")
combination_folders = {}
for org_name, level in unique_combinations:
    folder_name = f"{org_name}_{level}"
    # Pass calibration_drive_id as the parent_id to create the folder inside the calibration drive
    folder_id = calibrone.create_google_drive_folder(
        folder_name, parent_id=calibration_drive_id
    )
    combination_folders[(org_name, level)] = folder_id
    folders_per_org[org_name] += 1  # Update folder count for org_name
    print(f"Folder '{folder_name}' created with ID: {folder_id}")

# Listing files from given calibration folder
print(f"Listing files from folder ID: {macro_area_calibration_folder_id}")
employees_file_name = calibrone.list_files_in_google_drive(macro_area_calibration_folder_id)

for file_id, file_name in employees_file_name:
    # Extract email from file name
    match = re.search(email_pattern, file_name)
    if match:
        employee_email = match.group()
        # Search for the employee in the organization hierarchy
        employee_details = calibrone.search_employee(org_hierarchy, employee_email)

        if employee_details:
            name, email, manager, role, level, org_name, reports = (
                employee_details.values()
            )

            # Find upper managers' hierarchy
            upper_managers_emails = calibrone.find_upper_managers_hierarchy(
                org_hierarchy, employee_email
            )

            # Identify the correct folder ID using level and org_name
            target_folder_id = combination_folders.get((org_name, level))

            if target_folder_id:
                # Move the file to the identified folder
                calibrone.copy_file_to_folder(file_id, target_folder_id)
                files_per_folder[target_folder_id] += 1  # Update file count for the folder

                moved_files_info.append({
                    "File Name": file_name, 
                    "File ID": file_id, 
                    "Target Folder ID": target_folder_id
                })

                # Set folder permissions for each upper manager
                for manager_email in upper_managers_emails:
                    calibrone.set_folder_permissions(target_folder_id, manager_email)

            else:
                print(f"No target folder found for {org_name} at level {level}.")
        else:
            print(
                f"Employee with email {employee_email} not found in the organization hierarchy."
            )
    else:
        print(f"Email not found in file name: {file_name}")

# Calculate execution time
end_time = time.time()
execution_time = end_time - start_time

# Prepare data for printing
folders_per_org_data = [[org, f"{count} folders"] for org, count in folders_per_org.items()]
files_per_folder_data = [[folder_name, f"{count} files"] for folder_id, count in files_per_folder.items() for (name, level), id in combination_folders.items() if id == folder_id]

# Print statistics using tabulate
print("\nStatistics:\n")
print(tabulate(folders_per_org_data, headers=["Organization", "Folders"]))

print("\nFiles per Folder:")
print(tabulate(files_per_folder_data, headers=["Folder Name", "Files"]))

print(f"\nExecution Time: {execution_time:.2f} seconds\n")


# Exportar as informações dos arquivos movidos para Excel
moved_files_excel_path = "files/moved_files_info.xlsx"
moved_files_df = pd.DataFrame(moved_files_info)
moved_files_df.to_excel(moved_files_excel_path, index=False)
print(f"Moved files information exported to {moved_files_excel_path}")

# Export folder IDs to Excel
excel_file_path = "files/folder_ids.xlsx"
df = pd.DataFrame([(org_name, level, folder_id) for (org_name, level), folder_id in combination_folders.items()],
                  columns=["Org Name", "Level", "Folder ID"])
df.to_excel(excel_file_path, index=False)
print(f"Folder IDs exported to {excel_file_path}")